namespace LegacyApp.Common
{
    public enum ClientStatus
    {
        Gold = 1,
        Platinum = 2,
        Titanium = 3
    }
}
